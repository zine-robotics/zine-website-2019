Cufon.replace('#header .nav li a', { fontFamily: 'Myriad Pro', hover:true });
Cufon.replace('h2', { fontFamily: 'Myriad Pro' });