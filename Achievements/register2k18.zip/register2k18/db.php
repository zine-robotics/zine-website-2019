<?php
   //$conn = mysqli_connect("localhost","vishal_kothari","register2k18","vishal_kothari");
   
   
   
   
$servername = "localhost";
$username = "vishal_kothari";
$password = "register2k18";
$db="Registration";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

   
  
?>